export interface Alumno {
  id: number;
  nia: string;
  nombre: string;
  apellidos: string;
  grupo: number;
}

export interface Grupo {
  id: number;
  nombre: string;
}
